using UnityEngine;
using UnityEngine.UI;
using TMPro;

// Bu bile�en, bir GameObject'e (Kale/Oyuncu) atanabilir
// veya UI prefab'� i�inde bulunup harici bir hedefe ba�lanabilir.
public class HealthBarUI : MonoBehaviour
{
    [Header("UI Bile�enleri")]
    [Tooltip("Can de�erini g�sterecek Slider.")]
    [SerializeField] private Slider healthSlider;

    [Tooltip("Can de�eri (�rne�in: 50/100) g�sterecek Text bile�eni.")]
    [SerializeField] private TMP_Text healthText;

    [Tooltip("Can bar�n�n takip edece�i hedef (Can kayna��).")]
    [SerializeField] private GameObject targetObject;

    private IHealthProvider healthProvider;
   // private Damageable damageableTarget;

    private Transform mainCameraTransform;
    private void Start()
    {
        if (Camera.main != null)
        {
            mainCameraTransform = Camera.main.transform;
        }
        // 2. IHealthProvider aray�z�n� ara (Oyuncu i�in)
        healthProvider = targetObject.GetComponent<IHealthProvider>();

        if (healthProvider != null)
        {
            // OYUNCU (IHealthProvider) S�STEM�:
            healthProvider.OnHealthChanged += UpdateHealthUI;
            UpdateHealthUI(healthProvider.CurrentHealth, healthProvider.MaxHealth); // Property kulland���n�z� varsayarak g�ncellendi
        }
        else
        {
            // 3. DAMAGEABLE (KALE/D��MAN) S�STEM�:
           /* damageableTarget = targetObject.GetComponent<Damageable>();

            if (damageableTarget != null)
            {
                // YEN�: Damageable'�n olay�na abone ol!
                damageableTarget.OnHealthChanged += UpdateHealthUI;

                // Ba�lang�� de�erlerini al
                float current = damageableTarget.CurrentHealth;
                float max = damageableTarget.GetMaxHealth(); // Art�k MaxHealth'e do�rudan eri�ilebilir
                UpdateHealthUI(current, max);
            }
            else
            {
                Debug.LogError($"HealthBarUI: Hedef obje ({targetObject.name}) �zerinde ne IHealthProvider ne de Damageable bulundu!");
            }*/
        }
    }
    private void LateUpdate()
    {
        if (mainCameraTransform == null) return;

        Vector3 directionToCamera = mainCameraTransform.position - transform.position;

        if (directionToCamera == Vector3.zero) return; 
        Quaternion targetRotation = Quaternion.LookRotation(-directionToCamera);
        targetRotation.y = 0;
        targetRotation.z = 0;
        transform.rotation = targetRotation;
    }
    private void OnDestroy()
    {
        // Abonelikten ��kmay� unutma!
        if (healthProvider != null)
        {
            healthProvider.OnHealthChanged -= UpdateHealthUI;
        }
        /*if (damageableTarget != null)
        {
           damageableTarget.OnHealthChanged -= UpdateHealthUI;
        }*/
    }
   
    private void UpdateHealthUI(float currentHealth, float maxHealth)
    {
        if (healthSlider != null)
        {
            healthSlider.maxValue = maxHealth;
            healthSlider.value = currentHealth;
        }

        if (healthText != null)
        {
            healthText.text = $"{Mathf.CeilToInt(currentHealth)} / {Mathf.CeilToInt(maxHealth)}";
        }
    }
}