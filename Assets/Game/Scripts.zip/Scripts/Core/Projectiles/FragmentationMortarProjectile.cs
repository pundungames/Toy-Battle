// FragmentationMortarProjectile.cs
using UnityEngine;
using Zenject;
using System.Collections.Generic;

public class FragmentationMortarProjectile : ProjectileBase
{
    // [Inject] public LayerMask enemyLayerMask; // E�er ProjectileBase'de yoksa, DI ile enjekte edin

    // DamageTower'dan gelmesi gereken enemyLayerMask'i alabilmek i�in ge�ici bir de�i�ken.
    // Normalde bu bilgi kule taraf�ndan SetTarget'a parametre olarak g�nderilmelidir.
    private LayerMask enemyLayerMask;
   // private DamageTower tower;
    [SerializeField] ParticleSystem extraVfx;
    // Tower'dan gelen verileri tutmak i�in yeni bir SetParams metodu ekleyebiliriz.
    public void SetParams(LayerMask enemyLayer, float radius/*, DamageTower tower*/)
    {
        this.enemyLayerMask = enemyLayer;
        this.damageRange = radius; // Patlama yar��ap�: 2 blok
     //   this.tower = tower;
    }

    // BASE SINIFTAK� ThrowBomb METODU �OK UZUN VE GENEL DE��L. 
    // Patlama mant���n� uygulayacak bir metodu buradan �a��raca��z.
    public override void ThrowBomb(Transform owner, Vector3 target, float damage, float bombDelay, ParticleSystem extraVfx = null)
    {
        // Temel f�rlatma animasyonu (ThrowBomb'dan kopyalanan kod)
        // ... (DOTween Sequence ve DOJump mant���) ...

        // Buray� temiz tutmak i�in base s�n�f�n ThrowBomb metodunu override etmeyece�iz. 
        // Ancak base s�n�f�n ThrowBomb'� final hasar verme k�sm�n� kapsad��� i�in, 
        // ya onu de�i�tirmeli ya da burada kendi patlama mant���m�z� eklemeliyiz.

        base.ThrowBomb(owner, target, damage, bombDelay, this.extraVfx);

        // E�er base.ThrowBomb'un sonunda hasar verme k�sm� bo�sa (�u an yorum sat�r�nda), 
        // patlama an�nda �al��acak yeni bir callback yazmal�y�z.
        // Base s�n�ftaki ThrowBomb metodu incelendi�inde, hasar verme k�sm� yorum sat�r�nda:
        // //� �List<Transform> targets = SkillUtility.GetUnitsInRange(...);
        // Bu y�zden, patlama mant���m�z� patlaman�n oldu�u yere eklemeliyiz.
    }

    // Base s�n�ftaki ThrowBomb'u patlama an�nda bu metodu �a��racak �ekilde d�zenleyelim.
    // Varsayal�m ki, bu mermi objesi, DOTween animasyonu bitti�inde �a�r�lacak bir metot i�ermeli.

    // Patlama an�nda �a�r�lacak yeni bir metot tan�ml�yoruz.
    protected override void Explode(Vector3 explosionCenter)
    {
        // Range: 2 blok �ap�ndaki radius
        Collider[] hitColliders = Physics.OverlapSphere(explosionCenter, damageRange, enemyLayerMask);

        // AoE alan hasar�: her d��mana 30 damage
        foreach (var hitCollider in hitColliders)
        {
            if (hitCollider.TryGetComponent(out Damageable target))
            {
                // Hasar uygulama (30 damage)
                /*if (target is EnemyBase)
                    target.TakeDamage(tower.CallculateEnemyDamage(target as EnemyBase, attackDamage), damageType, true); // True: Loot d���rs�n*/
            }
        }
        Debug.Log("Explode Mortar");
        extraVfx.Play();
        Destroy(gameObject, .5f);
        // NOT: Patlama VFX'i ve merminin yok edilmesi, base s�n�f�n ThrowBomb metodu i�inde hallediliyor olmal�.
        // E�er edilmiyorsa, buraya eklenmeli.
        // Base s�n�f�n ThrowBomb'� zaten sona erdi�inde poolingSystem.DestroyAPS(gameObject) �a��r�yor.
    }

    // Bu mermi t�r� isabetle tetiklenmedi�i i�in OnTriggerEnter'a ihtiyac�m�z yok.
    protected override void OnTriggerEnter(Collider other)
    {
        // Bo� b�rak
    }
}