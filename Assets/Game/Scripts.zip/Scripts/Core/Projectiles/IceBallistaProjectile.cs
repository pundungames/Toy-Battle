using UnityEngine;
using System.Collections.Generic;
using Zenject;

// IceBallista'n�n mermisi i�in �zel s�n�f
public class IceBallistaProjectile : ProjectileBase
{
    // Hangi d��manlara vurdu�umuzu takip etmek i�in bir liste
    private readonly List<Damageable> hitEnemies = new List<Damageable>();

    // Bir d��mana ilk vuru� yap�l�p yap�lmad���n� kontrol eden bayrak
    private bool hasHitFirstTarget = false;

    // ProjectileBase'den kal�t�m ald���m�z i�in sadece ihtiyac�m�z olan metodu override ediyoruz.

    // OnCollisionEnter metodunu kullanaca��z ��nk� merminin �arpt�ktan sonra yok olmamas� gerekiyor.
    protected override void OnTriggerEnter(Collider other)
    {
        // Temas edilen nesnenin bir d��man olup olmad���n� kontrol et.
        if (other.gameObject.TryGetComponent<Damageable>(out Damageable enemy))
        {
            // Bu d��mana daha �nce vurulmad�ysa VE
            // Hen�z ilk hedefe vurulmad�ysa (bu merminin vuru� hakk� varsa)
            if (!hitEnemies.Contains(enemy) && !hasHitFirstTarget)
            {
                // HASAR VERME ��LEM�
                AttackToEnemy(enemy);

                // Bu d��man� vuru� listesine ekle (�imdilik bu projede gerek yok, ama olas� geli�tirmeler i�in iyi)
                // hitEnemies.Add(enemy); 

                // Merminin ilk ve tek vuru� hakk�n� kulland���n� i�aretle
                hasHitFirstTarget = true;

                // �lk vuru� yap�ld��� i�in buradaki i�lem biter, mermi yoluna devam eder.
            }
            // NOT: hasHitFirstTarget true ise, mermi di�er d��manlar�n i�inden hasar vermeden ge�meye devam edecektir.
        }
    }

    // NOT: Mermi yok olma i�lemini OnCollisionEnter yerine,
    // Ekran d���na ��kt���nda (Out of Bounds) veya
    // Bir s�re sonra otomatik olarak (�rne�in 5-10 saniye sonra) yapmal�s�n�z.
    // Base s�n�ftaki OnCollisionEnter metodunu iptal etmek i�in OnCollisionEnter metodunu kald�rmal� veya bo� b�rakmal�y�z:
    // Merminiz �u anki "ProjectileBase" s�n�f�n�zda "OnCollisionEnter" ile �al���yor.
    // �arp��man�n bir kez olmas�n� sa�lamak i�in **Base s�n�ftaki `OnCollisionEnter` metodunu bo� b�rakmal�y�z**
    // ancak `ProjectileBase` bir soyut (abstract) s�n�f oldu�undan, buna gerek kalmayabilir.
    // E�er merminiz bir Collider de�il de bir **Trigger Collider** kullanacaksa,
    // **`OnCollisionEnter`** yerine **`OnTriggerEnter`** kullanman�z gerekir, b�ylece i�inden ge�er.

    // E�er fiziksel �arp��ma (OnCollisionEnter) kullanmak istiyorsan�z ve i�inden ge�mesini sa�lamak zor ise,
    // en kolay yol budur. Mermi objenizin **Is Trigger** olarak ayarland���ndan emin olun.

    // E�er hala OnCollisionEnter kullanmak istiyorsan�z ve sadece ilk hedefe vurmak istiyorsan�z:
    // ----------------------------------------------------------------------------------------------------------------------
    // public override void AttackToEnemy(EnemyBase target) { ... } metodunuzu override etmeniz GEREKMEZ.
    // ��nk� `AttackToEnemy` hasar� verip mermiyi siliyor.
    // Base s�n�ftaki `OnCollisionEnter`'� iptal edip, kendi `OnCollisionEnter`'�n�z� yaz�n:

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.TryGetComponent<Damageable>(out Damageable enemy))
        {
            if (!hasHitFirstTarget)
            {
                // HASAR VERME
                AttackToEnemy(enemy); // BU METOT ZATEN SONUNDA M�HM�Y� S�L�YOR!

                // Merminin yok olmas�n� istemedi�imiz i�in, Base s�n�ftaki `AttackToEnemy` metodunu da de�i�tirmemiz gerekiyor!
            }
            // else: Mermi ikinci d��mana �arpt�, hasar vermeden i�inden ge�iyor (E�er fiziksel �arp��ma (Collision) yerine Trigger kullan�rsan�z)
            // E�er fiziksel �arp��ma kullan�yorsan�z, mermi burada duracak veya sektirecektir. Bu y�zden **Trigger** kullanmak en do�rusudur.
        }
    }

    // ----------------------------------------------------------------------------------------------------------------------

    // �lk hedefe vurduktan sonra yok olmamas� i�in, base s�n�ftaki AttackToEnemy metodunu ge�ersiz k�lmal�s�n�z.
    protected override void AttackToEnemy(Damageable target)
    {
        if (target == null) return;

        target.TakeDamage(attackDamage, true);

        // Vuru� VFX'lerini oynat.
        if (poolingSystem != null && hitVfxName != string.Empty)
        {
            Vector3 pos = target.transform.position; pos.y = transform.position.y;
            GameObject vfx = poolingSystem.InstantiateAPS(hitVfxName, pos);
            poolingSystem.DestroyAPS(vfx, 2f);
        }

        // Mermiyi yok etme kodunu BURADAN KALDIRIYORUZ!
        // poolingSystem.DestroyAPS(gameObject);

        // �lk hedefe vurdu�unu i�aretle.
        hasHitFirstTarget = true;
    }

    // Mermi geri �a�r�ld���nda (pool'a d�nd���nde) veya devre d��� b�rak�ld���nda vuru� durumunu s�f�rlay�n.
    protected override void OnDisable()
    {
        base.OnDisable();
        hasHitFirstTarget = false;
        hitEnemies.Clear();
        // Merminin sonsuz gitmesi gerekti�i i�in, yok olma i�lemini burada yapmay�n�z. 
        // Bunu bir zamanlay�c� veya ekran d��� kontrol� ile yap�n.
        // �imdilik, sadece merminin Base s�n�ftan kal�t�m alarak pool'a d�nd���n� varsay�yorum.
    }
}

// NOT: Yukar�daki kodun �al��mas� i�in, mermi objenizin **Collider bile�eninde Is Trigger** i�aretli olmal�d�r!
// Ayr�ca Base s�n�ftaki `OnCollisionEnter` metodunu **mutlaka silmeli veya bo� b�rakmal�s�n�z**.