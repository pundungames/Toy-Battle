// GunnersBrigadeProjectile.cs
using UnityEngine;

public class GunnersBrigadeProjectile : ProjectileBase
{
    // Bu mermi tipi, her d��mana isabet etti�inde hasar verebilmelidir.

    protected override void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.TryGetComponent<Damageable>(out Damageable enemy))
        {
            // Base s�n�f�n AttackToEnemy metodunu �a��r
            AttackToEnemy(enemy);

            // Merminin yok edilmesi Base s�n�f�n AttackToEnemy'de yap�l�yordu.
            // E�er merminin *birden fazla* d��mana vurmas�n� istiyorsak, 
            // AttackToEnemy metodunda mermiyi yok eden sat�r� K�KTEN KALDIRMALIYIZ (ProjectileBase'i de�i�tirerek)
            // Ya da sadece burada override ederek merminin yok edilmesini engelleriz:

            // NOT: Base s�n�f�n AttackToEnemy metodu mermiyi yok ediyor. 
            // Bu nedenle, �oklu vuru� istiyorsak bu metodu override etmeliyiz.
        }
    }

    protected override void AttackToEnemy(Damageable target)
    {
        if (target == null) return;

        // Hasar verme
        target.TakeDamage(attackDamage, true);

        // Merminin yok edilmesi, menzili tamamlayana kadar ERTELEN�R.
        // Base s�n�f�n yok etme mant���, ProjectileFlight'�n sonunda �al��acakt�r.
    }
}