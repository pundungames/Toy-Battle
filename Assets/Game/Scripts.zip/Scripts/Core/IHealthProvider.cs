public interface IHealthProvider
{
    /// <summary>
    /// Maksimum can de�erini d�nd�r�r.
    /// </summary>
    float MaxHealth { get; }

    /// <summary>
    /// Mevcut can de�erini d�nd�r�r.
    /// </summary>
    float CurrentHealth { get; }

    /// <summary>
    /// Can de�erleri de�i�ti�inde (hasar alma, iyile�me) tetiklenir.
    /// </summary>
    // System.Action<MevcutCan, MaksimumCan> imzas�na sahiptir.
    public event System.Action<float, float> OnHealthChanged;

    /// <summary>
    /// Belirtilen miktarda can ekler (iyile�me).
    /// </summary>
    void RestoreHealth(float amount);

    // Not: Hasar alma i�lemi genellikle bu interface'i uygulayan
    // Damageable veya CharacterStatManager'�n i�inden �a�r�ld��� i�in 
    // buraya "TakeDamage" eklenmesi zorunlu de�ildir.
}