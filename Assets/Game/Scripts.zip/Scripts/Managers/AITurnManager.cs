﻿// ============================================================================
// AI TURN MANAGER - AI'ın draft turn'ünü yönetir
// ✅ UPDATED: Multi-unit spawn support
// ✅ FIXED: Enemy rotation (face player)
// ============================================================================

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Zenject;

public class AITurnManager : MonoBehaviour
{
    [Inject] AIController aiController;
    [Inject] GridManager gridManager;
    [Inject] BonusSystem bonusSystem;
    [Inject] UnlockSystem unlockSystem;

    [Header("AI Settings")]
    [SerializeField] float aiThinkDelay = 1f; // AI karar verme süresi
    [SerializeField] float aiActionDelay = 0.5f; // AI action sonrası bekleme

    [Header("Card Pool")]
    [SerializeField] List<ToyUnitData> allToyUnits;
    [SerializeField] List<BonusCardData> allBonusCards;

    [Header("Rarity Weights")]
    [SerializeField] int commonWeight = 70;
    [SerializeField] int rareWeight = 27;
    [SerializeField] int epicWeight = 3;

    private bool isAITurnActive = false;

    // ===== START AI TURN =====

    public void StartAITurn()
    {
        if (isAITurnActive)
        {
            Debug.LogWarning("AI turn already active!");
            return;
        }

        isAITurnActive = true;
        StartCoroutine(ExecuteAITurnCoroutine());
    }

    private IEnumerator ExecuteAITurnCoroutine()
    {
        Debug.Log("🤖 AI is thinking...");

        // AI thinking delay
        yield return new WaitForSeconds(aiThinkDelay);

        // Generate AI draft cards (same logic as player)
        List<object> aiDraftCards = GenerateAIDraftCards();

        if (aiDraftCards.Count == 0)
        {
            Debug.LogWarning("⚠️ AI: No cards available!");
            isAITurnActive = false;
            OnAITurnComplete();
            yield break;
        }

        // AI makes decision
        object selectedCard = aiController.SelectCard(aiDraftCards);

        Debug.Log($"🤖 AI selected: {GetCardName(selectedCard)}");

        // Execute AI action
        ExecuteAIAction(selectedCard);

        // Wait before completing turn
        yield return new WaitForSeconds(aiActionDelay);

        // AI turn complete
        isAITurnActive = false;
        OnAITurnComplete();
    }

    // ===== GENERATE AI CARDS =====

    private List<object> GenerateAIDraftCards()
    {
        List<object> cards = new List<object>();

        if (allToyUnits == null || allToyUnits.Count == 0)
        {
            Debug.LogError("❌ AITurnManager: allToyUnits is empty!");
            return cards;
        }

        // Get unlocked units
        List<ToyUnitData> unlockedUnits = unlockSystem != null ?
            unlockSystem.GetUnlockedUnits(allToyUnits) :
            new List<ToyUnitData>(allToyUnits);

        List<ToyUnitData> availableUnits = new List<ToyUnitData>(unlockedUnits);

        // Add 2 unique toy units
        for (int i = 0; i < 2; i++)
        {
            if (availableUnits.Count == 0) break;

            ToyUnitData randomUnit = GetWeightedRandomUnit(availableUnits);
            if (randomUnit != null)
            {
                cards.Add(randomUnit);
                availableUnits.Remove(randomUnit);
            }
        }

        // 15% chance for bonus card
        if (Random.value < 0.15f && allBonusCards != null && allBonusCards.Count > 0)
        {
            BonusCardData randomBonus = allBonusCards[Random.Range(0, allBonusCards.Count)];
            cards.Add(randomBonus);
        }
        else
        {
            if (availableUnits.Count > 0)
            {
                ToyUnitData randomUnit = GetWeightedRandomUnit(availableUnits);
                if (randomUnit != null)
                {
                    cards.Add(randomUnit);
                }
            }
        }

        return cards;
    }

    private ToyUnitData GetWeightedRandomUnit(List<ToyUnitData> units)
    {
        if (units.Count == 0) return null;

        int totalWeight = 0;
        Dictionary<ToyUnitData, int> weights = new Dictionary<ToyUnitData, int>();

        foreach (var unit in units)
        {
            int weight = unit.toyRarityType switch
            {
                RarityType.Common => commonWeight,
                RarityType.Rare => rareWeight,
                RarityType.Epic => epicWeight,
                _ => 1
            };

            weights.Add(unit, weight);
            totalWeight += weight;
        }

        int randomValue = Random.Range(0, totalWeight);
        foreach (var kvp in weights)
        {
            randomValue -= kvp.Value;
            if (randomValue <= 0)
                return kvp.Key;
        }

        return units[0];
    }

    // ===== EXECUTE AI ACTION (FIXED!) =====

    private void ExecuteAIAction(object selectedCard)
    {
        if (selectedCard is ToyUnitData unitData)
        {
            // ✅ FIXED: Correct SpawnUnit signature
            // isPlayer = false for AI/enemy units
            bool spawned = gridManager.SpawnUnit(unitData, false);

            if (spawned)
            {
                Debug.Log($"✅ AI spawned: {unitData.toyName}");

                // ✅ ROTATION FIX: Make sure enemy units face player
                FixEnemyUnitsRotation();
            }
            else
            {
                Debug.LogWarning($"❌ AI: Cannot spawn {unitData.toyName} - Grid may be full or prefab missing!");
            }
        }
        else if (selectedCard is BonusCardData bonusData)
        {
            // AI uses bonus
            Debug.Log($"🤖 AI used bonus: {bonusData.bonusName}");

            if (bonusSystem != null)
            {
                // Apply bonus to AI units
                // bonusSystem.ApplyBonusToEnemy(bonusData);
            }
        }
    }

    // ===== FIX ENEMY ROTATION =====

    private void FixEnemyUnitsRotation()
    {
        // ✅ Get all enemy units and ensure they face player (180 degrees)
        List<RuntimeUnit> enemyUnits = gridManager.GetEnemyUnits();

        foreach (var unit in enemyUnits)
        {
            if (unit != null && unit.gameObject != null)
            {
                // ✅ Enemy units should face SOUTH (towards player)
                // Y rotation = 180 means facing down/south
                unit.transform.rotation = Quaternion.Euler(0, 180, 0);
            }
        }

        Debug.Log($"🔄 Fixed rotation for {enemyUnits.Count} enemy units");
    }

    // ===== AI TURN COMPLETE =====

    private void OnAITurnComplete()
    {
        Debug.Log("🤖 AI turn complete!");

        // Notify that both turns are complete, game can continue
        EventManager.OnDraftComplete();
    }

    // ===== HELPERS =====

    private string GetCardName(object card)
    {
        if (card is ToyUnitData unitData)
            return unitData.toyName;
        else if (card is BonusCardData bonusData)
            return bonusData.bonusName;
        else
            return "Unknown";
    }

    public bool IsAITurnActive()
    {
        return isAITurnActive;
    }
}