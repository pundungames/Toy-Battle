using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IExitable
{
    void Exit(Interactor interactor);
}
