using UnityEngine;
using DG.Tweening; // DoTween kullanmak i�in gerekli

public static class LootService
{
    // DoTween Parametreleri
    private const float JUMP_POWER = 4f;   // Z�plama y�ksekli�i
    private const float JUMP_DURATION = 0.8f; // Z�plama s�resi
    private const float FLOAT_DURATION = 1.5f; // S�z�lme (y�kselme/al�alma) s�resi
    private const float FLOAT_Y_OFFSET = 1f; // Y�ksekte s�z�lme miktar� (sizin iste�iniz)
    private const float SCATTER_RADIUS = 4f; // D��me �evresi (radius)

    private const float DROP_POSITION_Y_OFFSET = 0.5f; // Spawn pozisyonu Y ofseti (sizin iste�iniz)


    /// <summary>
    /// Verilen d���rme tablosuna g�re, belirlenen pozisyondan �d�l d���r�r ve DoTween ile animasyon uygular.
    /// </summary>
    public static void DropLoot(LootTableSO dropTable, Vector3 position)
    {
        if (dropTable == null)
        {
            Debug.LogError("DropLoot �a�r�ld� ancak LootTableSO bo� (Null).");
            return;
        }

        Vector3 spawnPosition = position + Vector3.up * DROP_POSITION_Y_OFFSET;

        foreach (var drop in dropTable.drops)
        {
            /*  // 1. Drop Olas�l��� Kontrol�
              if (Random.value > drop.dropChance)
              {
                  continue;
              }

              // 2. D���r�lecek miktar� hesapla
              // DropItemData'y� sizin min/maxAmount alanlar�n�za g�re g�ncelledik.
              int amountToDrop = Random.Range(drop.minAmount, drop.maxAmount + 1);

              if (amountToDrop <= 0 || drop.itemPrefab == null)
              {
                  continue;
              }
            */
            // 3. Her birimi ayr� ayr� d���r
            for (int i = 0; i < drop.dropAmount; i++)
            {
                GameObject droppedItem = GameObject.Instantiate(drop.itemPrefab, spawnPosition, Quaternion.identity);

                if (droppedItem != null)
                {
                    // Item'�n Rigidbody'si olmamal�.
                    if (droppedItem.GetComponent<Rigidbody>() != null)
                    {
                        Debug.LogWarning($"D�KKAT: '{droppedItem.name}' �zerinde Rigidbody bulundu! DoTween animasyonu ile �ak��abilir. Kald�r�lmas� �nerilir.");
                        // Rigidbody varsa, fizik ile �ak��mamas� i�in kapat�labilir.
                        // droppedItem.GetComponent<Rigidbody>().isKinematic = true;
                    }

                    ApplyDropAnimation(droppedItem.transform, spawnPosition);

                    // E�er d��en �ey XP ise, de�erini atayal�m
                 /*   XPPickup xpPickup = droppedItem.GetComponent<XPPickup>();
                    if (xpPickup != null)
                    {
                        xpPickup.SetXPValue(drop.xpValuePerUnit);
                    }
                 */
                    droppedItem.SetActive(true); // Pasif prefab'leri aktif et
                }
            }
        }
    }

    // --- YEN� AN�MASYON METODU ---
    private static void ApplyDropAnimation(Transform itemTransform, Vector3 startPosition)
    {
        // 1. Hedef Pozisyonu Hesapla
        Vector2 randomCircle = Random.insideUnitCircle * SCATTER_RADIUS;
        Vector3 endPosition = startPosition + new Vector3(randomCircle.x, 0, randomCircle.y);

        // 2. Sequence Olu�tur
        Sequence sequence = DOTween.Sequence();

        // --- 1. ADIM: Z�plama ---
        sequence.Append(
            itemTransform.DOJump(
                endPosition,
                JUMP_POWER,
                1,
                JUMP_DURATION
            ).SetEase(Ease.OutQuad)
        );

        // --- ARA ADIM: Z�plama biter bitmez bu kod �al���r ---
        sequence.AppendCallback(() =>
        {
            // Null check yapmak g�venlidir, obje yok olmu� olabilir
            if (itemTransform != null)
            {
               /* var item = itemTransform.GetComponent<CollectableItem>();
                if (item != null) item.moveable = true;*/
            }
        });

        // --- 2. ADIM: Sonsuz S�z�lme ---
        // Buras� sonsuz d�ng� oldu�u i�in sequence asla "Complete" olmaz.
        sequence.Append(
            itemTransform.DOMoveY(endPosition.y + FLOAT_Y_OFFSET, FLOAT_DURATION)
                .SetEase(Ease.InOutSine)
                .SetLoops(-1, LoopType.Yoyo)
        );

        sequence.Play();
    }
}