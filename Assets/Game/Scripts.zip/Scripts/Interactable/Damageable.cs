using UnityEngine;
using System.Collections;
using Zenject; // Coroutine'ler i�in gerekli

// Enemy ve ResourceNode i�in temel s�n�f. Can y�netimi ve hasar almay� sa�lar.
public abstract class Damageable : MonoBehaviour
{
    [Inject] internal AudioManager audioManager;

    [Header("Base Health Settings")]
    [Tooltip("Maksimum can de�eri.")]
    [SerializeField] internal float maxHealth = 10f;
    [SerializeField] internal float currentHealth;
    public float CurrentHealth => currentHealth;
    public event System.Action<float, float> OnHealthChanged; // (current, max)
    public float GetMaxHealth() { return maxHealth; }


    [Header("Base Loot Settings")]
    [Tooltip("Yok edildi�inde/k�r�ld���nda kullan�lacak LootTable Scriptable Object'i.")]
    [SerializeField] internal LootTableSO lootTable; // Alt s�n�flardan eri�ilebilir olmal�


    [Header("Resource Specific Feedback")]
    [SerializeField] private float hitScaleFactor = 1.1f;
    [SerializeField] private float hitRotationAngle = 10f;
    [SerializeField] private float hitDuration = 0.4f;

    private Vector3 originalScale;
    private Quaternion originalRotation;
    private bool isHitCoroutineRunning = false;

    // IHealthProvider sadece player i�in kullan�ld��� i�in, d��manlarda null kalacak.
    protected IHealthProvider healthProvider;


    // DOT Y�netimi i�in Alanlar
    private Coroutine dotCoroutine;
    private bool isBurning = false; // Basit kontrol bayra��

    [SerializeField] EnemyDamageText enemyDamageText;
    [SerializeField] float damageTextOffset = 2f;
    protected virtual void Awake()
    {
        // 1. G�rsel geri bildirim i�in ba�lang�� de�erlerini kaydet (Herkes i�in laz�m)
        originalScale = transform.localScale;
        originalRotation = transform.localRotation;

        // 2. IHealthProvider kontrol� (Oyuncu olup olmad���n� anlaman�n bir yolu) (Herkes i�in laz�m)
        healthProvider = GetComponent<IHealthProvider>();

        // 3. Can atamas�n� sadece oyuncu olmayan objeler yaps�n (Veya ayr� metotta yap�ls�n)
        InitializeHealth();
    }

    // Yeni: Can� ayarlama i�levini ay�r�yoruz.
    protected virtual void InitializeHealth()
    {
        // E�er obje oyuncu de�ilse (yani IHealthProvider yoksa), kendi can�n� ayarla.
        if (healthProvider == null)
        {
            currentHealth = maxHealth;
        }
    }
    public virtual void TakeHealth(float healthAmount = 0)
    {
        currentHealth += healthAmount;
        if (currentHealth > GetMaxHealth())
            currentHealth = GetMaxHealth();
        OnHealthChanged?.Invoke(CurrentHealth, GetMaxHealth());
    }

    /// <summary>
    /// D��ar�dan hasar almay� sa�layan ana metot.
    /// Oyuncu d���ndaki t�m objeler i�in (D��man, Kaynak, Kale) can azaltma mant���n� i�erir.
    /// </summary>
    /// <param name="damageAmount">Al�nan hasar miktar�.</param>
    public virtual void TakeDamage(float damageAmount, bool loot, Transform hitVfxPos = null) // �mza De�i�ti!
    {
        // E�er bu obje IHealthProvider uyguluyorsa (yani oyuncuysa),
        // hasar� ona y�nlendir ve temel mant��� atla.
        if (healthProvider != null)
        {
            // manager.ProcessIncomingDamage(damageAmount);
            OnHit(); // Oyuncu da vurulma feedback'i almal�
            return;
        }

        // Hasar almay� zaten s�f�ra d���rm�� objeler i�in kontrol
        if (currentHealth <= 0f) return;
        if (damageAmount <= 0f) return;

        // 1. Can� D���r (D��man/Kaynak/Kale)
        currentHealth -= damageAmount;
        OnHealthChanged?.Invoke(CurrentHealth, GetMaxHealth());
        if (enemyDamageText)
        {
            Vector3 pos = transform.position; pos.y += damageTextOffset;
            EnemyDamageText text = Instantiate(enemyDamageText, pos, Quaternion.identity, transform);
            text.SetTextAnimation(Mathf.CeilToInt(damageAmount).ToString("F0"));
        }
        // 2. Vurulma Geri Bildirimi
        OnHit();

        // Debug.Log($"{gameObject.name} Hasar Ald�. Kalan Can: {currentHealth}");

        // 3. �l�m Kontrol�
        if (currentHealth <= 0f)
        {
            currentHealth = 0f;
            OnDeathOrBreak(loot);
        }
    }

    /// <summary>
    /// Hasar al�nd���nda tetiklenecek eylemleri (Geri bildirim, ses) y�neten metot.
    /// </summary>
    protected virtual void OnHit()
    {
        if (!isHitCoroutineRunning)
        {
            StartCoroutine(HitFeedbackCoroutine());
        }
        // Alt s�n�flar (EnemyBase, Castle) ekstra efektler eklemek i�in bu metodu override edebilir.
    }

    private IEnumerator HitFeedbackCoroutine()
    {
        // ... (Bu metot ayn� kal�r, g�rsel feedback sa�lar)
        isHitCoroutineRunning = true;
        float timer = 0f;

        // Gerekirse orijinal Scale ve Rotation de�erlerinin al�nd���ndan emin ol (Awake'te atand�)
        if (originalScale == Vector3.zero) originalScale = transform.localScale;
        if (originalRotation == Quaternion.identity) originalRotation = transform.localRotation;

        while (timer < hitDuration)
        {
            float shakeIntensity = 1f - (timer / hitDuration);
            if (!enemyDamageText)
            {
                Quaternion randomShakeRotation = Quaternion.Euler(Random.insideUnitSphere * hitRotationAngle * shakeIntensity);
                transform.localRotation = originalRotation * randomShakeRotation;
            }

            float scalePop = 1 + Mathf.Sin(Mathf.PI * (timer / hitDuration)) * (hitScaleFactor - 1);
            transform.localScale = originalScale * scalePop;
            timer += Time.deltaTime;
            yield return null;
        }
        transform.localScale = originalScale;
        transform.localRotation = originalRotation;
        isHitCoroutineRunning = false;
    }

    /// <summary>
    /// Can� s�f�ra d��t���nde tetiklenen ortak mant�k.
    /// </summary>
    public virtual void OnDeathOrBreak(bool loot, bool kamikaze = false)
    {
        if (lootTable != null)
        {
            if (loot)
            {
                LootService.DropLoot(lootTable, transform.position);
            }
        }
        else
        {
        }

        // 2. Yok Etme (Alt s�n�flara b�rak�l�r)
        // Destory(gameObject) komutunu alt s�n�flara b�rakmak daha g�venlidir,�
        // ��nk� baz� d��manlar �l�m animasyonu oynatabilir.
    }


    public void ApplyDamageOverTime(float damagePerTick, float tickInterval, float duration)
    {
        // 1. Yeni DOT hasar�n� uygulayaca��z. �nceki ayn� tip DOT varsa durdur.
        if (isBurning && dotCoroutine != null)
        {
            return;
        }


        dotCoroutine = StartCoroutine(DamageOverTimeRoutine(damagePerTick, tickInterval, duration));
    }

    private IEnumerator DamageOverTimeRoutine(float damagePerTick, float tickInterval, float duration)
    {
        isBurning = true;
        float elapsedTime = 0f;

        // D��man �zerindeki g�rsel efekti ba�lat (�rn: Ate� VFX)
        // StartDotVFX(damageType); 

        while (elapsedTime < duration && CurrentHealth > 0)
        {
            // Belirtilen hasar tikini uygula
            TakeDamage(damagePerTick, false); // false: DOT hasar� loot d���rmez

            // Zaman� ilerlet
            elapsedTime += tickInterval;

            // Tik aral��� kadar bekle
            yield return new WaitForSeconds(tickInterval);
        }

        // DOT s�resi bitti veya d��man �ld�.
        isBurning = false;
        dotCoroutine = null;

        // D��man �zerindeki g�rsel efekti durdur
        // StopDotVFX(damageType);
    }
}