using UnityEngine;

[System.Serializable]
public struct DropItemData
{
    public GameObject itemPrefab;
    public int dropAmount;
    /*public int minAmount;
    public int maxAmount;
    [Tooltip("D���rme olas�l��� (0.0 = %0, 1.0 = %100).")]
    [Range(0f, 1f)]
    public float dropChance;*/

    [Header("XP Ayar�")]
    [Tooltip("E�er d��en item XP ise, bu, birim XP miktar�n� temsil eder.")]
    public float xpValuePerUnit;
}