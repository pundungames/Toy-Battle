public enum ResourceType
{
    Wood,
    Stone,
    XP,
    Health,
    Gold,
    // Di�er t�m toplanabilir e�ya t�rlerini buraya ekleyin
    Unknown // (Varsay�lan veya hata durumu i�in)
}